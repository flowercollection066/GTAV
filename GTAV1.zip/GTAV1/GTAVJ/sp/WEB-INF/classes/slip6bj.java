//slip6bj.java
// slip6B)Write a SERVLET program which counts how many times a user has visited a web    
//page. If user is visiting the page for the first time, display a welcome message. If the   
//user is revisiting the page, display the number of times visited. (Use Cookie) 

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class slip6bj extends HttpServlet
{
    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int count = 0;
        boolean newUser = true;

        Cookie c[] = request.getCookies();

        if(c != null)
        {
            for(int i = 0; i < c.length; i++)
            {
                if(c[i].getName().equals("visit"))
                {
                    count = Integer.parseInt(c[i].getValue());
                    newUser = false;
                }
            }
        }

        if(newUser)
        {
            count = 1;
            out.println("<h2>Welcome! This is your first visit.</h2>");
        }
        else
        {
            count++;
            out.println("<h2>You have visited this page " + count + " times.</h2>");
        }

        Cookie visitCookie = new Cookie("visit", String.valueOf(count));
        response.addCookie(visitCookie);

        out.println("<html>");
        out.println("<body>");
        out.println("<h3>Servlet Program Using Cookie</h3>");
        out.println("</body>");
        out.println("</html>");
    }
}