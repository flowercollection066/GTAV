//slip4bj.java
//slip4B) Write a SERVLET program that provides information about a HTTP request from a 
//client, such as IP address and browser type. The servlet also provides information about 
//the server on which the servlet is running, such as the operating system type, and the 
//names of currently loaded servlets. 

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class slip4bj extends HttpServlet {

    private ServletContext context;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        context = config.getServletContext();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>HTTP & Server Info</title></head><body>");
        out.println("<h1>Client Request Information</h1>");

        out.println("<p><strong>Client IP Address:</strong> " + request.getRemoteAddr() + "</p>");
        out.println("<p><strong>Browser Info:</strong> " + request.getHeader("User-Agent") + "</p>");
        out.println("<p><strong>Request Method:</strong> " + request.getMethod() + "</p>");
        out.println("<p><strong>Requested URL:</strong> " + request.getRequestURL() + "</p>");

        out.println("<h1>Server Information</h1>");

        out.println("<p><strong>Operating System:</strong> " + System.getProperty("os.name") + " " + System.getProperty("os.version") + "</p>");
        out.println("<p><strong>Java Version:</strong> " + System.getProperty("java.version") + "</p>");
        out.println("<p><strong>Server Info:</strong> " + context.getServerInfo() + "</p>");

        // Removed deprecated method getServletNames()
        out.println("<p><em>Listing loaded servlets is not supported in this version.</em></p>");

        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}