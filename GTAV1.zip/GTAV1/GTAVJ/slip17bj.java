//slip17bj.java
//slip17B)Write a Java program to check whether given file is present on server or not, if it is   
//there then display its contents on client’s terminal otherwise display the message “File   
//Not Found”. 

import java.io.*;
import java.util.Scanner;

public class slip17bj
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the full file path: ");
        String filePath = sc.nextLine();

        File file = new File(filePath);

        if(file.exists() && file.isFile())
        {
            System.out.println("\nFile found! Contents of the file:\n");

            try
            {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line;
                while((line = br.readLine()) != null)
                {
                    System.out.println(line);
                }
                br.close();
            }
            catch(IOException e)
            {
                System.out.println("Error reading file: " + e.getMessage());
            }
        }
        else
        {
            System.out.println("File Not Found");
        }

        sc.close();
    }
}

/*
RUN:

javac slip17bj.java
java slip17bj

INPUT:
Enter the full file path: C:\Users\HP\OneDrive\Desktop\ajava\text.txt
if only text.txt

OUTPUT (if file exists):
File found! Contents of the file:

Hello World
Java Program Example

OUTPUT (if file not found):
File Not Found
*/