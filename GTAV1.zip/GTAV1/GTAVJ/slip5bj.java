//slip5bj.java
//slip5B)Write a java program in multithreading using applet for Traffic signal(this program is in swing)

import javax.swing.*;
import java.awt.*;

class TrafficSignalPanel extends JPanel implements Runnable {
    Color redColor = Color.gray;
    Color yellowColor = Color.gray;
    Color greenColor = Color.gray;

    public void run() {
        try {
            while(true) {
                // RED ON
                redColor = Color.red;
                yellowColor = Color.gray;
                greenColor = Color.gray;
                repaint();
                Thread.sleep(5000);

                // YELLOW ON
                redColor = Color.gray;
                yellowColor = Color.yellow;
                greenColor = Color.gray;
                repaint();
                Thread.sleep(2000);

                // GREEN ON
                redColor = Color.gray;
                yellowColor = Color.gray;
                greenColor = Color.green;
                repaint();
                Thread.sleep(5000);
            }
        } catch(Exception e) {
            System.out.println(e);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw traffic signal box
        g.setColor(Color.black);
        g.fillRect(50, 50, 100, 300);

        // Draw RED light
        g.setColor(redColor);
        g.fillOval(75, 75, 50, 50);

        // Draw YELLOW light
        g.setColor(yellowColor);
        g.fillOval(75, 150, 50, 50);

        // Draw GREEN light
        g.setColor(greenColor);
        g.fillOval(75, 225, 50, 50);
    }
}

public class slip5bj extends JFrame {
    slip5bj() {
        setTitle("Traffic Signal - Slip5Bj");
        setSize(250, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        TrafficSignalPanel panel = new TrafficSignalPanel();
        add(panel);

        Thread t = new Thread(panel);
        t.start();

        setVisible(true);
    }

    public static void main(String[] args) {
        new slip5bj();
    }
}

//javac slip5bj.java

//java slip5bj.java