//slip4aj.java
//slip4A) Write a Java Program to delete details of students whose initial character of their 
//name is ‘S’. 

import java.util.*;

class Student
{
    int roll;
    String name;

    Student(int r, String n)
    {
        roll = r;
        name = n;
    }

    void display()
    {
        System.out.println("Roll No: " + roll + " Name: " + name);
    }
}

public class slip4aj
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> list = new ArrayList<Student>();

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();

        for(int i=0;i<n;i++)
        {
            System.out.print("Enter Roll No: ");
            int r = sc.nextInt();

            System.out.print("Enter Name: ");
            String name = sc.next();

            list.add(new Student(r,name));
        }

        System.out.println("\nStudent List Before Deletion:");
        for(Student s : list)
        {
            s.display();
        }

        Iterator<Student> it = list.iterator();

        while(it.hasNext())
        {
            Student s = it.next();

            if(s.name.startsWith("S"))
            {
                it.remove();
            }
        }

        System.out.println("\nStudent List After Deletion:");
        for(Student s : list)
        {
            s.display();
        }
    }
}

/*
Compile:
javac slip4aj.java

Run:
java slip4aj

Sample Output:

Enter number of students: 4
Enter Roll No: 1
Enter Name: Sagar
Enter Roll No: 2
Enter Name: Amit
Enter Roll No: 3
Enter Name: Sneha
Enter Roll No: 4
Enter Name: Rahul

Student List Before Deletion:
Roll No: 1 Name: Sagar
Roll No: 2 Name: Amit
Roll No: 3 Name: Sneha
Roll No: 4 Name: Rahul

Student List After Deletion:
Roll No: 2 Name: Amit
Roll No: 4 Name: Rahul

Note:
- Names starting with 'S' are deleted

*/