//slip6aj.java
//slip6A)Write a java program to blink image on the Frame continuously. 

import java.awt.*;

public class slip6aj extends Frame implements Runnable {

    Image img;
    boolean flag = true;
    Thread t;

    public slip6aj() {

        // Load image (Keep image in same folder or give full path)
        img = Toolkit.getDefaultToolkit().getImage("image.jpg");

        setTitle("Blinking Image");
        setSize(500, 500);
        setVisible(true);

        // Start thread
        t = new Thread(this);
        t.start();
    }

    public void paint(Graphics g) {

        if (flag) {
            g.drawImage(img, 150, 150, 200, 200, this);
        }
    }

    public void run() {

        while (true) {
            try {
                flag = !flag;   // Toggle image visibility
                repaint();      // Call paint()
                Thread.sleep(500);  // Blink every 500ms
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    public static void main(String args[]) {
        new slip6aj();
    }
}

//javac slip6a.java
//java slip6a.java
