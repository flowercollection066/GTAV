//slip2bj.java
//slip2B)Write a java program in multithreading using applet for drawing flag.

import javax.swing.*;
import java.awt.*;

// Panel class for drawing flag
class FlagPanel extends JPanel implements Runnable
{
    int x = 100;

    public void run()
    {
        try
        {
            while(true)
            {
                repaint();   // redraw
                Thread.sleep(1000);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);

        // Saffron
        g.setColor(Color.orange);
        g.fillRect(x,50,200,40);

        // White
        g.setColor(Color.white);
        g.fillRect(x,90,200,40);

        // Green
        g.setColor(Color.green);
        g.fillRect(x,130,200,40);

        // Ashoka Chakra
        g.setColor(Color.blue);
        g.drawOval(x+90,95,20,20);
    }
}

// Main class
public class slip2bj extends JFrame
{
    slip2bj()
    {
        setTitle("Indian Flag - Multithreading");
        setSize(500,300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        FlagPanel panel = new FlagPanel();
        add(panel);

        Thread t = new Thread(panel);
        t.start();

        setVisible(true);
    }

    public static void main(String args[])
    {
        new slip2bj();
    }
}

//javac slip2bj.java
//java slip2b.java