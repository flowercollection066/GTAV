//slip7aj.jsp
//slip7A)Write a JSP script to validate given E-Mail ID. 

<%@ page import="java.util.regex.*" %>

<html>
<head>
<title>Email Validation</title>
</head>
<body>

<h2>Email Validation Program</h2>

<form method="post">
Enter E-Mail ID : 
<input type="text" name="email">
<input type="submit" value="Validate">
</form>

<%
String email = request.getParameter("email");

if(email != null)
{
    String pattern = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";

    if(email.matches(pattern))
    {
        out.println("<h3 style='color:green'>Valid Email ID</h3>");
    }
    else
    {
        out.println("<h3 style='color:red'>Invalid Email ID</h3>");
    }
}
%>

</body>
</html>