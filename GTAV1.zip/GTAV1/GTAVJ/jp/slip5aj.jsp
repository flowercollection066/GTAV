//slip5aj.jsp
//slip5A) Write a JSP program to calculate sum of first and last digit of a given number. 
//Display sum in Red Color with font size 18.   

<%@ page language="java" %>
<html>
<head>
    <title>Sum of First and Last Digit</title>
</head>
<body>

<h2>Sum of First and Last Digit</h2>

<form method="post">
    Enter a number: <input type="text" name="num">
    <input type="submit" value="Calculate">
</form>

<%
    String numStr = request.getParameter("num");
    if(numStr != null && !numStr.isEmpty())
    {
        try
        {
            int num = Integer.parseInt(numStr);
            int lastDigit = num % 10;

            // Find first digit
            int firstDigit = num;
            while(firstDigit >= 10)
            {
                firstDigit = firstDigit / 10;
            }

            int sum = firstDigit + lastDigit;
%>
            <p style="color:red; font-size:18px;">
                Sum of first and last digit = <%= sum %>
            </p>
<%
        }
        catch(NumberFormatException e)
        {
%>
            <p style="color:red; font-size:18px;">
                Please enter a valid number!
            </p>
<%
        }
    }
%>

</body>
</html>