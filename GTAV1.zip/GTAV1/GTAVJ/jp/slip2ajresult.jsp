//slip2ajresult.jsp

<%@ page language="java" %>
<%@ include file="slip2ajperfect.jsp" %>

<html>
<body>

<%
int n = Integer.parseInt(request.getParameter("num"));
boolean result = isPerfect(n);

if(result)
{
    out.println(n + " is a Perfect Number");
}
else
{
    out.println(n + " is NOT a Perfect Number");
}
%>

</body>
</html>