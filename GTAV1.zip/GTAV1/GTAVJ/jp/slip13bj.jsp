//slip13b.jsp
//slip13B) Write a JSP program to display the details of College (CollegeID, Coll_Name, 
//Address) in tabular form on browser.  

<html>
<head>
<title>College Details</title>
</head>

<body>

<h2 align="center">College Information</h2>

<table border="1" align="center">
<tr>
<th>College ID</th>
<th>College Name</th>
<th>Address</th>
</tr>

<%
String cid[] = {"101","102","103","104"};
String cname[] = {"ABC College","XYZ College","PQR College","LMN College"};
String addr[] = {"Pune","Mumbai","Nashik","Aurangabad"};

for(int i=0;i<cid.length;i++)
{
%>

<tr>
<td><%= cid[i] %></td>
<td><%= cname[i] %></td>
<td><%= addr[i] %></td>
</tr>

<%
}
%>

</table>

</body>
</html>