//slip2aindex.jsp
//slip2A) Write a JSP program to check whether given number is Perfect or not. (Use Include 
//directive).  

<html>
<head>
<title>Perfect Number Check</title>
</head>
<body>

<h2>Check Perfect Number</h2>

<form action="slip2ajresult.jsp" method="post">
Enter Number: <input type="text" name="num">
<input type="submit" value="Check">
</form>

</body>
</html>