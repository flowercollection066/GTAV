//slip14aj.jsp
//slip14A)Write a JSP program to accept Name and Age of Voter and check whether he is   
 //eligible for voting or not. 

<html>
<head>
<title>Voter Eligibility Check</title>
</head>
<body>

<h2 align="center">Voter Eligibility Check</h2>

<form method="post">
    Name: <input type="text" name="name" required><br><br>
    Age: <input type="number" name="age" required><br><br>
    <input type="submit" value="Check Eligibility">
</form>

<%
String name = request.getParameter("name");
String ageStr = request.getParameter("age");

if(name != null && ageStr != null)
{
    int age = Integer.parseInt(ageStr);

    if(age >= 18)
    {
        out.println("<h3 style='color:green'>" + name + ", you are eligible to vote.</h3>");
    }
    else
    {
        out.println("<h3 style='color:red'>" + name + ", you are not eligible to vote.</h3>");
    }
}
%>

</body>
</html>