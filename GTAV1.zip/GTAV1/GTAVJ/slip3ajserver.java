//slip3ajserver.java
//slip3A) Write a socket program in Java to check whether given number is prime or not. 
//Display result on client terminal.

import java.net.*;
import java.io.*;

public class slip3ajserver
{
    public static void main(String args[]) throws Exception
    {
        ServerSocket ss = new ServerSocket(5000);
        System.out.println("Server started...");

        Socket s = ss.accept();
        System.out.println("Client connected");

        DataInputStream dis = new DataInputStream(s.getInputStream());
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());

        int num = dis.readInt();
        int i, flag = 0;

        for(i=2;i<=num/2;i++)
        {
            if(num%i==0)
            {
                flag=1;
                break;
            }
        }

        if(flag==0)
            dos.writeUTF(num + " is Prime Number");
        else
            dos.writeUTF(num + " is Not Prime Number");

        ss.close();
        s.close();
    }
}

/*
RUNNING PROCESS:

1) Open 2 CMD

SERVER:
javac slip3ajserver.java
java slip3ajserver

CLIENT:
javac slip3ajclient.java
java slip3ajclient

NOTE:
- First run server, then client
- Don’t use .java while running
*/