//slip7bj.java
//slip7B)Write a Multithreading program in java to display the number’s between 1 to 100  
//continuously in a TextField by clicking on button. (use Runnable Interface). 

import java.awt.*;
import java.awt.event.*;

public class slip7bj extends Frame implements Runnable, ActionListener
{
    TextField t1;
    Button b1;
    Thread t;

    slip7bj()
    {
        t1 = new TextField(20);
        b1 = new Button("Start");

        setLayout(new FlowLayout());
        add(t1);
        add(b1);

        b1.addActionListener(this);

        setSize(300,200);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e)
    {
        t = new Thread(this);
        t.start();
    }

    public void run()
    {
        try
        {
            for(int i=1;i<=100;i++)
            {
                t1.setText(String.valueOf(i));
                Thread.sleep(100);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public static void main(String args[])
    {
        new slip7bj();
    }
}

//javac slip7bj.java
//java slip7bj.java
