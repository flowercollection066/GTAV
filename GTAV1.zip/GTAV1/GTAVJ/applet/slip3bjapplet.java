//slip3bjapplet.java

import java.applet.Applet;
import java.awt.*;
import java.util.Random;

/*
<applet code="slip3bjapplet.class" width="400" height="300">
</applet>
*/

public class slip3bjapplet extends Applet implements Runnable {

    int x = 50, y = 50;
    int dx = 5, dy = 5;
    Thread t;
    Color ballColor = Color.red;
    Random rand = new Random();

    public void init() {
        t = new Thread(this);
        t.start();
    }

    public void run() {
        while (true) {

            x += dx;
            y += dy;

            // Bounce from left/right
            if (x <= 0 || x >= getWidth() - 50) {
                dx = -dx;
                changeColor();
            }

            // Bounce from top/bottom
            if (y <= 0 || y >= getHeight() - 50) {
                dy = -dy;
                changeColor();
            }

            repaint();

            try {
                Thread.sleep(30);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }

    // Random color change
    public void changeColor() {
        ballColor = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
    }

    public void paint(Graphics g) {
        g.setColor(ballColor);
        g.fillOval(x, y, 50, 50);
    }
}

//javac slip3bjapplet.java
//appletviewer slip3bjapplet.java