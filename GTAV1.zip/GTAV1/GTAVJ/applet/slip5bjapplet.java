//slip5bjapplet.java

import java.applet.Applet;
import java.awt.*;

/*
<applet code="slip5bjapplet.class" width="300" height="400">
</applet>
*/

public class slip5bjapplet extends Applet implements Runnable {

    Thread t;
    int state = 0; // 0=Red, 1=Yellow, 2=Green

    public void init() {
        t = new Thread(this);
        t.start();
    }

    public void run() {
        while (true) {
            state = (state + 1) % 3; // change signal

            repaint();

            try {
                Thread.sleep(2000); // 2 sec delay
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }

    public void paint(Graphics g) {

        // Signal box
        g.setColor(Color.black);
        g.fillRect(100, 50, 100, 250);

        // Red light
        if (state == 0)
            g.setColor(Color.red);
        else
            g.setColor(Color.gray);
        g.fillOval(120, 70, 60, 60);

        // Yellow light
        if (state == 1)
            g.setColor(Color.yellow);
        else
            g.setColor(Color.gray);
        g.fillOval(120, 140, 60, 60);

        // Green light
        if (state == 2)
            g.setColor(Color.green);
        else
            g.setColor(Color.gray);
        g.fillOval(120, 210, 60, 60);
    }
}

//javac slip5bjapplet.java
//appletviewer slip5bjapplet.java