//slip2bjapplet.java

import java.applet.Applet;
import java.awt.*;
import java.lang.Thread;

/*
<applet code="slip2bjapplet.class" width="400" height="300">
</applet>
*/

public class slip2bjapplet extends Applet implements Runnable {

    Thread t;

    public void init() {
        t = new Thread(this);
        t.start();
    }

    public void run() {
        while (true) {
            repaint();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }

    public void paint(Graphics g) {

        // Saffron
        g.setColor(Color.orange);
        g.fillRect(100, 50, 200, 50);

        // White
        g.setColor(Color.white);
        g.fillRect(100, 100, 200, 50);

        // Green
        g.setColor(Color.green);
        g.fillRect(100, 150, 200, 50);

        // Pole
        g.setColor(Color.black);
        g.fillRect(90, 50, 10, 200);

        // Ashoka Chakra
        g.setColor(Color.blue);
        g.drawOval(175, 110, 50, 50);

        // Spokes
        for (int i = 0; i < 360; i += 30) {
            double angle = Math.toRadians(i);
            int x1 = 200;
            int y1 = 135;
            int x2 = (int)(x1 + 25 * Math.cos(angle));
            int y2 = (int)(y1 + 25 * Math.sin(angle));
            g.drawLine(x1, y1, x2, y2);
        }
    }
}

//javac slip2bjapplet.java
//appletviewer slip2bjapplet.java