//slip14bj.java
//slip14B)Write a Java program to display given extension files from a specific directory on    
//server machine. 

import java.io.*;
import java.util.Scanner;

public class slip14bj
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Directory Path: ");
        String dirPath = sc.nextLine();

        System.out.print("Enter File Extension (e.g., txt, java): ");
        String ext = sc.nextLine();

        File dir = new File(dirPath);

        if(!dir.exists() || !dir.isDirectory())
        {
            System.out.println("Invalid directory path!");
            return;
        }

        String[] files = dir.list(new FilenameFilter() {
            public boolean accept(File dir, String name)
            {
                return name.endsWith("." + ext);
            }
        });

        if(files.length == 0)
        {
            System.out.println("No files with extension " + ext + " found in the directory.");
        }
        else
        {
            System.out.println("Files with extension ." + ext + " in directory " + dirPath + " :");
            for(String f : files)
            {
                System.out.println(f);
            }
        }

        sc.close();
    }
}

/*
RUN:

javac slip14bj.java
java slip14bj

INPUT:
Directory Path: C:\Users\HP\OneDrive\Desktop\ajava here add your folder path
Extension: java

OUTPUT:
slip1aj.java
slip4aj.java
slip13aj.java

(Note: Shows files with given extension)
*/
