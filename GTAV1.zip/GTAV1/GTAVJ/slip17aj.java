//slip17aj.java
//slip17A)Write a java program to accept a String from user and display each vowel from a   
//String after 3 seconds. 

import java.util.Scanner;

public class slip17aj
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = sc.nextLine();

        System.out.println("\nVowels in the string (displayed after 3 seconds each):");

        for(int i = 0; i < input.length(); i++)
        {
            char ch = input.charAt(i);

            if(isVowel(ch))
            {
                System.out.println(ch);

                try
                {
                    Thread.sleep(3000); // delay 3 seconds
                }
                catch(InterruptedException e)
                {
                    System.out.println("Thread interrupted: " + e);
                }
            }
        }

        sc.close();
    }

    // Method to check if character is vowel
    public static boolean isVowel(char c)
    {
        c = Character.toLowerCase(c);
        return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
    }
}

/*
RUN:

javac slip17aj.java
java slip17aj

INPUT:
Enter a string: Hello World

OUTPUT:
Vowels in the string (displayed after 3 seconds each):
e
o
o

(Note: Each vowel prints after 3 seconds delay)
*/