//slip13aj.java
//slip13A)Write a java program to display name of currently executing Thread in 
//multithreading. 

public class slip13aj extends Thread
{
    public void run()
    {
        System.out.println("Currently Executing Thread: " + Thread.currentThread().getName());
    }

    public static void main(String args[])
    {
        slip13aj t1 = new slip13aj();
        slip13aj t2 = new slip13aj();
        slip13aj t3 = new slip13aj();

        t1.start();
        t2.start();
        t3.start();
    }
}

/*

Compile:
javac slip13aj.java

Run:
java slip13aj

Output:

Currently Executing Thread: Thread-0
Currently Executing Thread: Thread-1
Currently Executing Thread: Thread-2

(Note: Order may change each time)

*/
