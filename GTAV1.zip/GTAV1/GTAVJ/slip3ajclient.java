//slip3ajclient.java
//slip3A) Write a socket program in Java to check whether given number is prime or not. 
//Display result on client terminal. 

import java.net.*;
import java.io.*;
import java.util.*;

public class slip3ajclient
{
    public static void main(String args[]) throws Exception
    {
        Socket s = new Socket("localhost",5000);

        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        DataInputStream dis = new DataInputStream(s.getInputStream());

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Number: ");
        int num = sc.nextInt();

        dos.writeInt(num);

        String result = dis.readUTF();
        System.out.println("Result from Server: " + result);

        s.close();
    }
}

/*
RUNNING PROCESS:

1) Open 2 CMD

SERVER:
javac slip3ajserver.java
java slip3ajserver

CLIENT:
javac slip3ajclient.java
java slip3ajclient

NOTE:
- First run server, then client
- Don’t use .java while running
*/