//slip3bj.java
//slip3B)Write a java program using applet for bouncing ball, for each bounce color of ball 
//should change randomly. 

import javax.swing.*;
import java.awt.*;
import java.util.Random;

class BallPanel extends JPanel implements Runnable
{
    int x = 50, y = 50;
    int dx = 5, dy = 5;
    int ballSize = 40;

    Color ballColor = Color.red;
    Random r = new Random();

    public void run()
    {
        try
        {
            while(true)
            {
                x = x + dx;
                y = y + dy;

                if(x <= 0 || x >= getWidth() - ballSize)
                {
                    dx = -dx;
                    changeColor();
                }

                if(y <= 0 || y >= getHeight() - ballSize)
                {
                    dy = -dy;
                    changeColor();
                }

                repaint();
                Thread.sleep(30);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    void changeColor()
    {
        ballColor = new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256));
    }

    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);

        g.setColor(ballColor);
        g.fillOval(x, y, ballSize, ballSize);
    }
}

public class slip3bj extends JFrame
{
    slip3bj()
    {
        setTitle("Bouncing Ball - Slip3Bj");
        setSize(400,300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        BallPanel panel = new BallPanel();
        add(panel);

        Thread t = new Thread(panel);
        t.start();

        setVisible(true);
    }

    public static void main(String args[])
    {
        new slip3bj();
    }
}

//javac slip3bj.java
//java slip3bj.java