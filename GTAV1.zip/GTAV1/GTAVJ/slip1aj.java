// File: slip1aj.java
//slip1A) Write a java program to scroll the text from left to right and vice versa continuously.

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class slip1aj extends JPanel implements ActionListener {

    private String text = " Welcome to Java Scrolling Text Demo! ";
    private int x; // x-position of text
    private int y; // y-position of text
    private int direction = 1; // 1 = left to right, -1 = right to left
    private Timer timer;

    public slip1aj() {   // ✅ constructor matches class name
        setBackground(Color.BLACK);
        setForeground(Color.GREEN);
        setFont(new Font("SansSerif", Font.BOLD, 24));

        x = 0;
        y = 50; // vertical position

        timer = new Timer(20, this); // update every 20ms for smooth scroll
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(getForeground());
        g.setFont(getFont());

        FontMetrics fm = g.getFontMetrics();
        int textWidth = fm.stringWidth(text);

        g.drawString(text, x, y);

        // Update x for scrolling
        x += direction * 2; // speed

        // Change direction when text hits edges
        if (x + textWidth > getWidth()) {
            direction = -1;
        } else if (x < 0) {
            direction = 1;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        repaint(); // repaint panel every timer tick
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Scrolling Text Demo");
        slip1aj scrollingText = new slip1aj();

        frame.add(scrollingText);
        frame.setSize(800, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

//javac slip1aj.java
//java slip1aj